import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Landing from './pages/Landing';
import Index from './pages/Index';
import Login from './components/Login';
import Signup from './components/Signup';
import Header from './components/Header';
import DashboardMain from './components/Dashboard/DashboardMain';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  const [user, setUser] = useState(null);

  return (
    <Router>
      <Header user={user} setUser={setUser} />
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/index" element={<Index />} />
        <Route path="/login" element={<Login setUser={setUser} />} />
        <Route path="/signup" element={<Signup setUser={setUser} />} />
        <Route path="/dashboard" element={
          <ProtectedRoute user={user}>
            <DashboardMain user={user} />
          </ProtectedRoute>
        } />
      </Routes>
    </Router>
  );
}

export default App;
