document.addEventListener("DOMContentLoaded", () => {

  // --- SIGNUP FORM ---
  const signupForm = document.getElementById("signupForm");
  if (signupForm) {
    const suEmail = document.getElementById("suEmail");
    const suRole = document.getElementById("suRole");

    // pre-fill last typed info
    const lastSuEmail = localStorage.getItem("lastSignupEmail");
    const lastSuRole = localStorage.getItem("lastSignupRole");
    if(lastSuEmail) suEmail.value = lastSuEmail;
    if(lastSuRole) suRole.value = lastSuRole;

    signupForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = document.getElementById("suName").value.trim();
      const email = suEmail.value.trim();
      const pass = document.getElementById("suPass").value;
      const pass2 = document.getElementById("suPass2").value;
      const role = suRole.value;

      if(pass !== pass2) {
        alert("Passwords do not match");
        return;
      }

      localStorage.setItem("ff_user_" + email, JSON.stringify({name,email,pass,role}));
      alert("Signup successful — please login");

      localStorage.setItem("lastSignupEmail", email);
      localStorage.setItem("lastSignupRole", role);

      window.location.href = "login.html";
    });
  }

  // --- LOGIN FORM ---
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    const liEmail = document.getElementById("liEmail");
    const liRole = document.getElementById("liRole");

    const savedEmail = localStorage.getItem("lastEmail");
    const savedRole = localStorage.getItem("lastRole");
    if(savedEmail) liEmail.value = savedEmail;
    if(savedRole) liRole.value = savedRole;

    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = liEmail.value.trim();
      const pass = document.getElementById("liPass").value;
      const role = liRole.value;

      const stored = JSON.parse(localStorage.getItem("ff_user_" + email));
      if(!stored || stored.pass !== pass || stored.role !== role){
        alert("Invalid credentials or role");
        return;
      }

      localStorage.setItem("loggedInEmail", email);
      localStorage.setItem("loggedInRole", role);

      localStorage.setItem("lastEmail", email);
      localStorage.setItem("lastRole", role);

      window.location.href = "dashboard.html";
    });
  }

  // --- DASHBOARD / LANDING PAGE ---
  const welcomeEl = document.getElementById("dashboard-welcome");
  const messageEl = document.getElementById("dashboard-message");
  const subPagesEl = document.getElementById("dashboard-subpages");
  const roleTitle = document.getElementById("roleTitle");
  const roleMessage = document.getElementById("roleMessage");
  const subPages = document.getElementById("subPages");
  const logoutBtn = document.getElementById("logoutBtn");

  const email = localStorage.getItem("loggedInEmail") || localStorage.getItem("email");
  const role = localStorage.getItem("loggedInRole");

  if((welcomeEl || roleTitle) && email && role) {

    // Role-specific content
    let welcomeText = "";
    let messageText = "";
    let linksHTML = "";

    switch(role.toLowerCase()){
      case "donor":
        welcomeText = `Hello ${email}`;
        messageText = "Thank you for being a generous Donor! Here are your options:";
        linksHTML = `
          <a href="#">View Donation Requests</a>
          <a href="#">My Donations</a>
          <a href="#">Donate Now</a>
        `;
        break;
      case "volunteer":
        welcomeText = `Hello ${email}`;
        messageText = "Welcome Volunteer! You can manage your volunteer activities here:";
        linksHTML = `
          <a href="#">Register for Events</a>
          <a href="#">My Volunteer History</a>
          <a href="#">Upcoming Volunteer Opportunities</a>
        `;
        break;
      case "receiver":
        welcomeText = `Hello ${email}`;
        messageText = "Welcome NGO! Here are your management options:";
        linksHTML = `
          <a href="#">View Donations</a>
          <a href="#">Request Support</a>
          <a href="#">Manage NGO Profile</a>
        `;
        break;
      case "admin":
        welcomeText = `Hello Admin ${email}`;
        messageText = "You can manage users and monitor donations here:";
        linksHTML = `
          <a href="#">Manage Users</a>
          <a href="#">Monitor Donations</a>
          <a href="#">System Settings</a>
        `;
        break;
      default:
        welcomeText = "Welcome Guest!";
        messageText = "Please login to access your dashboard.";
        linksHTML = "";
    }

    if(welcomeEl){
      welcomeEl.textContent = welcomeText;
      messageEl.textContent = messageText;
      subPagesEl.innerHTML = linksHTML;
    }

    if(roleTitle){
      roleTitle.textContent = role + " Dashboard";
      roleMessage.textContent = messageText;
      subPages.innerHTML = linksHTML;
    }
  } else if(welcomeEl || roleTitle){
    alert("Please login first");
    window.location.href = "login.html";
  }

  // --- LOGOUT BUTTON ---
  if(logoutBtn){
    logoutBtn.addEventListener("click", () => {
      localStorage.removeItem("loggedInEmail");
      localStorage.removeItem("loggedInRole");
      localStorage.removeItem("email");
      alert("You have been logged out.");
      window.location.href = "login.html";
    });
  }

});
