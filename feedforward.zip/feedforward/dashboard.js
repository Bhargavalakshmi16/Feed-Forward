document.addEventListener('DOMContentLoaded', () => {
  const user = App.getCurrentUser();
  if (!user) {
    alert('Please login');
    window.location.href = 'auth.html';
    return;
  }

  const subpages = document.getElementById('dashboard-subpages');
  subpages.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center">
    <div>
      <div style="font-weight:800;font-size:18px">Welcome, ${user.name}</div>
      <div class="small">Role: <strong>${user.role}</strong></div>
    </div>
    <div style="display:flex;gap:8px;">
      <button class="btn" id="logoutBtnTop">Logout</button>
      ${user.role === 'admin' ? '<a class="btn secondary" href="fridge.html">Fridge</a>' : ''}
    </div>
  </div>`;

  document.getElementById('logoutBtnTop').addEventListener('click', () => App.logout());

  const main = document.createElement('div');
  main.id = 'mainArea';
  subpages.appendChild(main);

  // Render role-specific UI
  if (user.role === 'donor') renderDonor(main, user);
  else if (user.role === 'volunteer') renderVolunteer(main, user);
  else if (user.role === 'receiver') renderReceiver(main, user);
  else if (user.role === 'admin') renderAdmin(main, user);
  else main.innerHTML = '<div class="card">Unknown role</div>';
});

/* ===== Donor UI ===== */
function renderDonor(container, user) {
  container.innerHTML = `<div class="card section"><h3>Post a Donation</h3>
    <form id="donForm">
      <div class="form-row"><input id="dTitle" class="input" placeholder="Title (e.g., 10 meals)" required></div>
      <div class="form-row"><input id="dQty" class="input" type="number" placeholder="Quantity (meals)" required></div>
      <div class="form-row"><input id="dAddr" class="input" placeholder="Pickup address"></div>
      <div class="form-row"><input id="dExpiry" class="input" type="datetime-local"></div>
      <div class="form-row"><button class="btn" type="submit">Post Donation</button></div>
    </form></div>
    <div class="card section"><h3>Your Donations</h3><div id="donList" class="list small"></div></div>`;

  loadDonationsForUser(user);

  document.getElementById('donForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const title = document.getElementById('dTitle').value.trim();
    const qty = Number(document.getElementById('dQty').value) || 1;
    const addr = document.getElementById('dAddr').value.trim();
    const expiry = document.getElementById('dExpiry').value || null;
    App.createDonation({ donorId: user.id, title, quantity: qty, address: addr, expiry });
    alert('Donation posted');
    loadDonationsForUser(user);
    this.reset();
  });
}

function loadDonationsForUser(user) {
  const list = document.getElementById('donList');
  const donations = App.getDonations().filter(d => d.donorId === user.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  if (!donations.length) {
    list.innerHTML = '<div class="small">No donations yet</div>';
    return;
  }

  list.innerHTML = donations.map(d =>
    `<div class="item">
      <div>
        <div style="font-weight:700">${escapeHtml(d.title)}</div>
        <div class="small">Qty:${d.quantity} • Status:${d.status} • ${d.address || ''}</div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn" onclick="markPicked('${d.id}')">Mark Picked</button>
        <button class="btn secondary" onclick="moveToFridge('${d.id}')">Move to Fridge</button>
      </div>
    </div>`).join('');
}

function markPicked(id) {
  try { App.deliverDonation(id); alert('Marked picked'); loadDonationsForUser(App.getCurrentUser()); }
  catch (e) { alert(e.message); }
}

function moveToFridge(id) {
  try { App.moveToFridge(id); alert('Moved to fridge'); loadDonationsForUser(App.getCurrentUser()); }
  catch (e) { alert(e.message); }
}

/* ===== Volunteer UI ===== */
function renderVolunteer(container, user) {
  container.innerHTML = `<div class="card section"><h3>Available Donations</h3><div id="availList" class="list small"></div></div>
                         <div class="card section"><h3>Assigned Tasks</h3><div id="assignedList" class="list small"></div></div>`;
  loadVolunteer();
}

function loadVolunteer() {
  const donations = App.getDonations();
  const areas = App.getAreas();

  function areaPriority(addr) {
    if (!addr) return 0;
    const a = areas.find(x => x.name.toLowerCase() === (addr || '').toLowerCase());
    return a ? (a.highPriority ? 2 : 1) : 0;
  }

  const avail = donations.filter(d => d.status === 'available')
    .sort((a, b) => areaPriority(b.address) - areaPriority(a.address) || new Date(a.createdAt) - new Date(b.createdAt));

  document.getElementById('availList').innerHTML = avail.length ? avail.map(d =>
    `<div class="item">
      <div>
        <div style="font-weight:700">${escapeHtml(d.title)}</div>
        <div class="small">${d.quantity} • ${d.address || ''}</div>
      </div>
      <div style="display:flex;flex-direction:column;gap:6px">
        <button class="btn" onclick="accept('${d.id}')">Accept</button>
        <a class="btn secondary" target="_blank" href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(d.address||'')}">Map</a>
      </div>
    </div>`).join('') : '<div class="small">No available donations</div>';

  const assigned = donations.filter(d => d.status === 'booked' && d.bookedBy === App.getCurrentUser().id);
  document.getElementById('assignedList').innerHTML = assigned.length ? assigned.map(d =>
    `<div class="item">
      <div>
        <div style="font-weight:700">${escapeHtml(d.title)}</div>
        <div class="small">${d.quantity} • ${d.address || ''}</div>
      </div>
      <div style="display:flex;flex-direction:column;gap:6px">
        <button class="btn" onclick="deliver('${d.id}')">Mark Delivered</button>
        <a class="btn secondary" target="_blank" href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(d.address||'')}">Map</a>
      </div>
    </div>`).join('') : '<div class="small">No assigned tasks</div>';
}

function accept(id) { try { App.acceptDonation(id, App.getCurrentUser().id); alert('Accepted'); loadVolunteer(); } catch (e) { alert(e.message); } }
function deliver(id) { try { App.deliverDonation(id); alert('Delivered'); loadVolunteer(); } catch (e) { alert(e.message); } }

/* ===== Receiver UI ===== */
function renderReceiver(container, user) {
  container.innerHTML = `<div class="card section"><h3>Available Donations</h3><div id="recvAvail" class="list small"></div></div>
                         <div class="card section"><h3>Your Requests</h3><div id="recvReq" class="list small"></div></div>`;
  loadReceiver();
}

function loadReceiver() {
  const available = App.getDonations().filter(d => d.status === 'available');
  document.getElementById('recvAvail').innerHTML = available.length ? available.map(d =>
    `<div class="item">
      <div>
        <div style="font-weight:700">${escapeHtml(d.title)}</div>
        <div class="small">${d.quantity} • ${d.address || ''}</div>
      </div>
      <div style="display:flex;flex-direction:column;gap:6px">
        <button class="btn" onclick="requestPickup('${d.id}')">Request Pickup</button>
        <a class="btn secondary" target="_blank" href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(d.address||'')}">Map</a>
      </div>
    </div>`).join('') : '<div class="small">No available donations</div>';

  const myReqs = App.getDonations().filter(d => d.requestedBy === App.getCurrentUser().id || (d.status === 'booked' && d.bookedBy === App.getCurrentUser().id));
  document.getElementById('recvReq').innerHTML = myReqs.length ? myReqs.map(d =>
    `<div class="item">
      <div>
        <div style="font-weight:700">${escapeHtml(d.title)}</div>
        <div class="small">Status: ${d.status}</div>
      </div>
      <div><button class="btn" onclick="confirmPickup('${d.id}')">Confirm Pickup</button></div>
    </div>`).join('') : '<div class="small">No active requests</div>';
}

function requestPickup(id) { try { App.bookDonation(id, App.getCurrentUser().id); alert('Requested'); loadReceiver(); } catch (e) { alert(e.message); } }
function confirmPickup(id) { try { App.deliverDonation(id); alert('Pickup confirmed'); loadReceiver(); } catch (e) { alert(e.message); } }

/* ===== Admin UI ===== */
function renderAdmin(container, user) {
  container.innerHTML = `<div class="card section"><h3>Users</h3><div id="adminUsers" class="list small"></div></div>
    <div class="card section"><h3>Areas</h3>
      <form id="areaForm">
        <div class="form-row"><input id="areaName" class="input" placeholder="Area name" required></div>
        <div class="form-row"><input id="areaBeggars" class="input" type="number" placeholder="No. of beggars"></div>
        <div class="form-row"><input id="areaHandi" class="input" type="number" placeholder="No. of handicapped"></div>
        <div class="form-row"><label><input id="areaHigh" type="checkbox"> High priority area</label></div>
        <div class="form-row"><button class="btn" type="submit">Add/Update</button></div>
      </form>
    </div>
    <div class="card section"><h3>Fridge</h3><div id="adminFridge" class="list small"></div></div>
    <div class="card section"><h3>All Donations</h3><div id="adminDons" class="list small"></div></div>`;
  
  loadAdmin();
  document.getElementById('areaForm').addEventListener('submit', function(e) {
    e.preventDefault();
    App.addOrUpdateArea({
      name: document.getElementById('areaName').value.trim(),
      beggars: Number(document.getElementById('areaBeggars').value),
      handicapped: Number(document.getElementById('areaHandi').value),
      highPriority: document.getElementById('areaHigh').checked
    });
    alert('Saved');
    loadAdmin();
    this.reset();
  });
}

function loadAdmin() {
  const users = getUsers();
  document.getElementById('adminUsers').innerHTML = users.length ? users.map(u =>
    `<div class="item">
      <div><div style="font-weight:700">${escapeHtml(u.name)} (${u.role})</div><div class="small">${u.email}</div></div>
      <div style="display:flex;gap:6px">
        <button class="btn" onclick="verifyUser('${u.id}')">Verify</button>
        <button class="btn secondary" onclick="blockUser('${u.id}')">Block</button>
      </div>
    </div>`).join('') : '<div class="small">No users</div>';

  const fridge = App.getFridge();
  document.getElementById('adminFridge').innerHTML = fridge.length ? fridge.map(f =>
    `<div class="item">
      <div><div style="font-weight:700">${escapeHtml(f.title)}</div><div class="small">Qty:${f.quantity} • ${new Date(f.storedAt).toLocaleString()}</div></div>
      <div><button class="btn secondary" onclick="removeFridge('${f.id}')">Remove</button></div>
    </div>`).join('') : '<div class="small">No fridge items</div>';

  const dons = App.getDonations().sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  document.getElementById('adminDons').innerHTML = dons.length ? dons.map(d =>
    `<div class="item">
      <div><div style="font-weight:700">${escapeHtml(d.title)}</div><div class="small">Qty:${d.quantity} • ${d.address || ''} • ${d.status}</div></div>
      <div style="display:flex;gap:6px">
        <button class="btn" onclick="moveToFridge('${d.id}')">Move to Fridge</button>
        <button class="btn secondary" onclick="deleteDonation('${d.id}')">Delete</button>
      </div>
    </div>`).join('') : '<div class="small">No donations</div>';
}

/* ===== Admin Helpers ===== */
function verifyUser(id) {
  const users = getUsers();
  const u = users.find(x => x.id === id);
  if (u) { u.verified = true; saveUsers(users); alert('Verified'); loadAdmin(); }
}

function blockUser(id) {
  const users = getUsers();
  const u = users.find(x => x.id === id);
  if (u) { u.blocked = !u.blocked; saveUsers(users); alert('Toggled block'); loadAdmin(); }
}

function removeFridge(id) {
  const f = getFridge().filter(x => x.id !== id);
  saveFridge(f);
  loadAdmin();
}

/* ===== Utilities ===== */
function escapeHtml(s) {
  if (!s) return '';
  return String(s).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m]);
}
